//
//  CustomTableViewCell.swift
//  FoodPin
//
//  Created by 000 on 15/9/10.
//  Copyright (c) 2015年 000. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    var nameLabel: UILabel!
    var locationLabel: UILabel!
    var typeLabel: UILabel!
    var thumbnailImageView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected statex
    }
    
     func cellWithTableView(tableView:UITableView) -> UITableViewCell
    {
                var cell = tableView.dequeueReusableCellWithIdentifier("sub") as? UITableViewCell
                if ((cell) == nil) {
                 cell = CustomTableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "sub")
                        //self.init(style: UITableViewStyle.Plain, reuseIdentifier: "sub")
                }
                return cell!;
    }
    
//     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as! UITableViewCell
//        //        let cell = tableView.dequeueReusableCellWithIdentifier("cell",indexPath) as! UITableViewCell
//        cell = CustomTableViewCell().
//            // Configure the cell...
//            cell.textLabel!.text = "aa"
//        //            String(format:"%d",indexPath.row)
//        cell.backgroundColor = UIColor.redColor();
//        //        cell.textLabel!.text = self.items[indexPath.row];
//        return cell
//    }
//    {
//       return nil;
//    }
    
//    class func  cellWithTableView(tableView:UITableView) -> self!
//    {
////        static ID = @"sub";
//        let cell = tableView.dequeueReusableCellWithIdentifier("sub") as! UITableViewCell
//        if (cell?) {
//            cell = CustomTableViewCell(style: UITableViewCellStyleSubtitle, reuseIdentifier: ID)
//        }
//        return nil;
//    }
//    + (instancetype)cellWithTableView:(UITableView *)tableView
//    {
//
//    }

}
